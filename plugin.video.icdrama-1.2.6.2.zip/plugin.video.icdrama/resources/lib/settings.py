import xbmcaddon

_addon = xbmcaddon.Addon()

title_lang = int(_addon.getSetting('title_language'))
