import xbmcaddon

title_lang = int(xbmcaddon.Addon().getSetting('title_language'))
